<?php
$page_title = "Apply for Loan - Easy Funds 4 You";
$page_description = "Apply for a loan with Easy Funds 4 You. Fast and easy application process for personal, business, asset finance, education, and emergency loans.";

session_start();

// Get loan type from URL parameter if available
$selected_loan_type = isset($_GET['loan_type']) ? $_GET['loan_type'] : '';
$selected_amount = isset($_GET['amount']) ? $_GET['amount'] : '';
$selected_duration = isset($_GET['duration']) ? $_GET['duration'] : '';

include 'includes/header.php';
?>

        <!-- Hero Start-->
        <div class="hero-area2  slider-height2 hero-overly2 d-flex align-items-center apply-hero">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="hero-cap text-center pt-50">
                            <h2>Apply Form</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Hero End -->
        <!-- Apply Area Start -->
        <div class="apply-area pt-150 pb-150">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <div class="application-form-wrapper">
                            <h2 class="form-title">Loan Application Form</h2>
                            <p class="form-subtitle">Fill out the form below to apply for a loan. All fields marked with <span style="color: #EF4444;">*</span> are required.</p>
                            
                            <?php if (isset($_SESSION['errors'])): ?>
                            <div class="application-alert alert-danger">
                                <strong><i class="fas fa-exclamation-circle"></i> Please correct the following errors:</strong>
                                <ul>
                                    <?php foreach ($_SESSION['errors'] as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                            <?php 
                            unset($_SESSION['errors']);
                            $form_data = isset($_SESSION['form_data']) ? $_SESSION['form_data'] : [];
                            endif; 
                            if (!isset($form_data)) $form_data = []; ?>
                            
                            <!-- Form -->
                            <form action="process_application.php" method="POST" id="loanApplicationForm">
                                <!-- Loan Information Section -->
                                <div class="form-section">
                                    <h3 class="section-title">
                                        <i class="fas fa-file-invoice-dollar"></i>
                                        Loan Information
                                    </h3>
                                    
                                    <div class="row">
                                        <!-- Loan Type -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Loan Type <span class="required">*</span></label>
                                                <select name="loan_type" id="loan_type" class="form-control" required>
                                                    <option value="">Choose Loan Type</option>
                                                    <option value="personal" <?php echo ($selected_loan_type == 'personal' || $selected_loan_type == 'Personal_Loan') ? 'selected' : ''; ?>>Personal Loan</option>
                                                    <option value="business" <?php echo ($selected_loan_type == 'business' || $selected_loan_type == 'Business_Loan') ? 'selected' : ''; ?>>Business Loan</option>
                                                    <option value="asset" <?php echo ($selected_loan_type == 'asset' || $selected_loan_type == 'Asset_Finance_Loan') ? 'selected' : ''; ?>>Asset Finance Loan</option>
                                                    <option value="education" <?php echo ($selected_loan_type == 'education' || $selected_loan_type == 'Education_Loan') ? 'selected' : ''; ?>>Education Loan</option>
                                                    <option value="emergency" <?php echo ($selected_loan_type == 'emergency' || $selected_loan_type == 'Emergency_Loan') ? 'selected' : ''; ?>>Emergency Loan</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <!-- Loan Amount -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Loan Amount (RWF) <span class="required">*</span></label>
                                                <input type="number" name="loan_amount" id="loan_amount" class="form-control" placeholder="Enter loan amount" value="<?php echo htmlspecialchars($selected_amount); ?>" required>
                                            </div>
                                        </div>
                                        
                                        <!-- Loan Duration -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Loan Duration <span class="required">*</span></label>
                                                <select name="loan_duration" id="loan_duration" class="form-control" required>
                                                    <option value="">Choose Duration</option>
                                                    <option value="7" <?php echo ($selected_duration == '7') ? 'selected' : ''; ?>>7 Days</option>
                                                    <option value="14" <?php echo ($selected_duration == '14') ? 'selected' : ''; ?>>14 Days</option>
                                                    <option value="30" <?php echo ($selected_duration == '30') ? 'selected' : ''; ?>>30 Days (1 Month)</option>
                                                    <option value="60" <?php echo ($selected_duration == '60') ? 'selected' : ''; ?>>60 Days (2 Months)</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Personal Information Section -->
                                <div class="form-section">
                                    <h3 class="section-title">
                                        <i class="fas fa-user"></i>
                                        Personal Information
                                    </h3>
                                    
                                    <div class="row">
                                        <!-- First Name -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>First Name <span class="required">*</span></label>
                                                <input type="text" name="first_name" class="form-control" placeholder="Enter first name" value="<?php echo isset($form_data['first_name']) ? htmlspecialchars($form_data['first_name']) : ''; ?>" required>
                                            </div>
                                        </div>
                                        
                                        <!-- Last Name -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Last Name <span class="required">*</span></label>
                                                <input type="text" name="last_name" class="form-control" placeholder="Enter last name" value="<?php echo isset($form_data['last_name']) ? htmlspecialchars($form_data['last_name']) : ''; ?>" required>
                                            </div>
                                        </div>
                                        
                                        <!-- Gender -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Gender <span class="required">*</span></label>
                                                <div class="radio-group">
                                                    <div class="radio-option">
                                                        <input id="radio-male" name="gender" type="radio" value="male" checked>
                                                        <label for="radio-male">Male</label>
                                                    </div>
                                                    <div class="radio-option">
                                                        <input id="radio-female" name="gender" type="radio" value="female">
                                                        <label for="radio-female">Female</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Marital Status -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Marital Status <span class="required">*</span></label>
                                                <select name="marital_status" id="marital_status" class="form-control" required>
                                                    <option value="">Choose Status</option>
                                                    <option value="single">Single</option>
                                                    <option value="married">Married</option>
                                                    <option value="divorced">Divorced</option>
                                                    <option value="widowed">Widowed</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <!-- Number of Dependants -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Number of Dependants <span class="required">*</span></label>
                                                <select name="dependants" id="dependants" class="form-control" required>
                                                    <option value="">Choose Option</option>
                                                    <option value="0">0</option>
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                    <option value="5+">5+</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <!-- Email Address -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Email Address <span class="required">*</span></label>
                                                <input type="email" name="email" class="form-control" placeholder="your.email@example.com" value="<?php echo isset($form_data['email']) ? htmlspecialchars($form_data['email']) : ''; ?>" required>
                                            </div>
                                        </div>
                                        
                                        <!-- Phone Number -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Phone Number <span class="required">*</span></label>
                                                <input type="tel" name="phone" class="form-control" placeholder="+250788123456" value="<?php echo isset($form_data['phone']) ? htmlspecialchars($form_data['phone']) : ''; ?>" required>
                                                <small class="form-helper">Include country code (e.g., +250)</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Address Information Section -->
                                <div class="form-section">
                                    <h3 class="section-title">
                                        <i class="fas fa-map-marker-alt"></i>
                                        Address Information
                                    </h3>
                                    
                                    <div class="row">
                                        <!-- City -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Town/City <span class="required">*</span></label>
                                                <input type="text" name="city" class="form-control" placeholder="Enter city" value="<?php echo isset($form_data['city']) ? htmlspecialchars($form_data['city']) : ''; ?>" required>
                                            </div>
                                        </div>
                                        
                                        <!-- Street -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Street Address <span class="required">*</span></label>
                                                <input type="text" name="street" class="form-control" placeholder="Enter street address" value="<?php echo isset($form_data['street']) ? htmlspecialchars($form_data['street']) : ''; ?>" required>
                                            </div>
                                        </div>
                                        
                                        <!-- House Number -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>House Name/Number <span class="required">*</span></label>
                                                <input type="text" name="house_number" class="form-control" placeholder="Enter house name or number" value="<?php echo isset($form_data['house_number']) ? htmlspecialchars($form_data['house_number']) : ''; ?>" required>
                                            </div>
                                        </div>
                                        
                                        <!-- Homeowner Status -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Homeowner Status <span class="required">*</span></label>
                                                <select name="homeowner_status" id="homeowner_status" class="form-control" required>
                                                    <option value="">Choose Status</option>
                                                    <option value="owner">Owner</option>
                                                    <option value="renter">Renter</option>
                                                    <option value="living_with_family">Living with Family</option>
                                                    <option value="other">Other</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Employment Information Section -->
                                <div class="form-section">
                                    <h3 class="section-title">
                                        <i class="fas fa-briefcase"></i>
                                        Employment Information
                                    </h3>
                                    
                                    <div class="row">
                                        <!-- Employment Industry -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Employment Industry <span class="required">*</span></label>
                                                <input type="text" name="employment_industry" class="form-control" placeholder="e.g., Finance, Technology, Education" value="<?php echo isset($form_data['employment_industry']) ? htmlspecialchars($form_data['employment_industry']) : ''; ?>" required>
                                            </div>
                                        </div>
                                        
                                        <!-- Employer Name -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Employer Name <span class="required">*</span></label>
                                                <input type="text" name="employer_name" class="form-control" placeholder="Enter employer name" value="<?php echo isset($form_data['employer_name']) ? htmlspecialchars($form_data['employer_name']) : ''; ?>" required>
                                            </div>
                                        </div>
                                        
                                        <!-- Work Phone -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Work Phone Number <span class="required">*</span></label>
                                                <input type="tel" name="work_phone" class="form-control" placeholder="+250788123456" value="<?php echo isset($form_data['work_phone']) ? htmlspecialchars($form_data['work_phone']) : ''; ?>" required>
                                            </div>
                                        </div>
                                        
                                        <!-- Monthly Income -->
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Monthly Income (RWF) <span class="required">*</span></label>
                                                <input type="number" name="monthly_income" class="form-control" placeholder="Enter monthly income" value="<?php echo isset($form_data['monthly_income']) ? htmlspecialchars($form_data['monthly_income']) : ''; ?>" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Additional Information Section -->
                                <div class="form-section">
                                    <h3 class="section-title">
                                        <i class="fas fa-info-circle"></i>
                                        Additional Information
                                    </h3>
                                    
                                    <div class="row">
                                        <!-- Additional Notes -->
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label>Additional Notes (Optional)</label>
                                                <textarea name="notes" class="form-control" rows="4" placeholder="Any additional information you'd like to provide..."><?php echo isset($form_data['notes']) ? htmlspecialchars($form_data['notes']) : ''; ?></textarea>
                                                <small class="form-helper">This information will help us process your application faster.</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Submit Button -->
                                <button type="submit" class="btn-submit" id="submitBtn">
                                    <i class="fas fa-paper-plane"></i>
                                    Submit Application
                                </button>
                            </form>
                            
                            <?php 
                            // Clear form data after displaying (only if no errors)
                            if (isset($_SESSION['form_data']) && !isset($_SESSION['errors'])) {
                                unset($_SESSION['form_data']);
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Apply Area End -->
        
        <script>
        // Form submission handler
        document.addEventListener('DOMContentLoaded', function() {
            var form = document.getElementById('loanApplicationForm');
            var submitBtn = document.getElementById('submitBtn');
            
            if (form && submitBtn) {
                form.addEventListener('submit', function(e) {
                    // Disable button to prevent double submission
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
                    
                    // Allow form to submit normally
                    return true;
                });
            }
        });
        </script>

<?php include 'includes/footer.php'; ?>

