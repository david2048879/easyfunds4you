<?php
/**
 * Application Detail View
 */
$page_title = 'Application Details';
include 'includes/header.php';

$conn = getDBConnection();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $new_status = $_POST['status'];
    $notes = isset($_POST['notes']) ? $_POST['notes'] : '';
    
    $stmt = $conn->prepare("UPDATE loan_applications SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $new_status, $id);
    if ($stmt->execute()) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                Application status updated successfully!
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
              </div>';
    }
    $stmt->close();
}

// Get application details
$stmt = $conn->prepare("SELECT * FROM loan_applications WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$app = $result->fetch_assoc();

if (!$app) {
    echo '<div class="alert alert-danger">Application not found.</div>';
    include 'includes/footer.php';
    exit;
}
?>

<div class="row mb-4">
    <div class="col-md-12">
        <a href="applications.php" class="btn btn-secondary mb-3">
            <i class="fas fa-arrow-left"></i> Back to Applications
        </a>
    </div>
</div>

<div class="row">
    <!-- Application Details -->
    <div class="col-md-8">
        <div class="table-responsive">
            <h4 class="mb-3">Application #<?php echo str_pad($app['id'], 6, '0', STR_PAD_LEFT); ?></h4>
            
            <table class="table table-bordered">
                <tr>
                    <th width="30%">Application ID</th>
                    <td>#<?php echo str_pad($app['id'], 6, '0', STR_PAD_LEFT); ?></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>
                        <span class="badge badge-<?php echo $app['status']; ?>">
                            <?php echo ucfirst($app['status']); ?>
                        </span>
                    </td>
                </tr>
                <tr>
                    <th>Loan Type</th>
                    <td><?php echo ucfirst(htmlspecialchars($app['loan_type'])); ?></td>
                </tr>
                <tr>
                    <th>Loan Amount</th>
                    <td><strong>RWF <?php echo number_format($app['loan_amount'], 2); ?></strong></td>
                </tr>
                <tr>
                    <th>Loan Duration</th>
                    <td><?php echo $app['loan_duration']; ?> days</td>
                </tr>
                <tr>
                    <th>First Name</th>
                    <td><?php echo htmlspecialchars($app['first_name']); ?></td>
                </tr>
                <tr>
                    <th>Last Name</th>
                    <td><?php echo htmlspecialchars($app['last_name']); ?></td>
                </tr>
                <tr>
                    <th>Gender</th>
                    <td><?php echo ucfirst(htmlspecialchars($app['gender'])); ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><a href="mailto:<?php echo htmlspecialchars($app['email']); ?>"><?php echo htmlspecialchars($app['email']); ?></a></td>
                </tr>
                <tr>
                    <th>Phone</th>
                    <td><a href="tel:<?php echo htmlspecialchars($app['phone']); ?>"><?php echo htmlspecialchars($app['phone']); ?></a></td>
                </tr>
                <tr>
                    <th>Marital Status</th>
                    <td><?php echo ucfirst(htmlspecialchars($app['marital_status'])); ?></td>
                </tr>
                <tr>
                    <th>Number of Dependants</th>
                    <td><?php echo htmlspecialchars($app['dependants']); ?></td>
                </tr>
                <tr>
                    <th>Address</th>
                    <td>
                        <?php echo htmlspecialchars($app['house_number']); ?>, 
                        <?php echo htmlspecialchars($app['street']); ?>, 
                        <?php echo htmlspecialchars($app['city']); ?>
                    </td>
                </tr>
                <tr>
                    <th>Homeowner Status</th>
                    <td><?php echo ucfirst(str_replace('_', ' ', htmlspecialchars($app['homeowner_status']))); ?></td>
                </tr>
                <tr>
                    <th>Employment Industry</th>
                    <td><?php echo htmlspecialchars($app['employment_industry']); ?></td>
                </tr>
                <tr>
                    <th>Employer Name</th>
                    <td><?php echo htmlspecialchars($app['employer_name']); ?></td>
                </tr>
                <tr>
                    <th>Work Phone</th>
                    <td><?php echo htmlspecialchars($app['work_phone']); ?></td>
                </tr>
                <tr>
                    <th>Monthly Income</th>
                    <td><strong>RWF <?php echo number_format($app['monthly_income'], 2); ?></strong></td>
                </tr>
                <?php if ($app['notes']): ?>
                <tr>
                    <th>Additional Notes</th>
                    <td><?php echo nl2br(htmlspecialchars($app['notes'])); ?></td>
                </tr>
                <?php endif; ?>
                <tr>
                    <th>Application Date</th>
                    <td><?php echo date('F d, Y h:i A', strtotime($app['created_at'])); ?></td>
                </tr>
            </table>
        </div>
    </div>
    
    <!-- Update Status -->
    <div class="col-md-4">
        <div class="table-responsive">
            <h5 class="mb-3">Update Status</h5>
            <form method="POST">
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" class="form-control" required>
                        <option value="pending" <?php echo $app['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="approved" <?php echo $app['status'] == 'approved' ? 'selected' : ''; ?>>Approved</option>
                        <option value="rejected" <?php echo $app['status'] == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                    </select>
                </div>
                <button type="submit" name="update_status" class="btn btn-primary btn-block">
                    <i class="fas fa-save"></i> Update Status
                </button>
            </form>
        </div>
    </div>
</div>

<?php 
$stmt->close();
closeDBConnection($conn);
include 'includes/footer.php'; 
?>



