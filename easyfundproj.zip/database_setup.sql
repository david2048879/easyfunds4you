-- Easy Funds 4 You Database Setup
-- Run this script in phpMyAdmin or MySQL command line

-- Create database
CREATE DATABASE IF NOT EXISTS easyfunds4you CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Use the database
USE easyfunds4you;

-- Table for loan applications
CREATE TABLE IF NOT EXISTS loan_applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    loan_type VARCHAR(50) NOT NULL,
    loan_amount DECIMAL(15,2) NOT NULL,
    loan_duration INT NOT NULL,
    gender VARCHAR(10),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    dependants VARCHAR(10),
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    marital_status VARCHAR(20),
    city VARCHAR(100),
    street VARCHAR(255),
    house_number VARCHAR(100),
    homeowner_status VARCHAR(50),
    employment_industry VARCHAR(255),
    employer_name VARCHAR(255),
    work_phone VARCHAR(50),
    monthly_income DECIMAL(15,2),
    notes TEXT,
    status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table for contact messages
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'unread',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table for news articles
CREATE TABLE IF NOT EXISTS news (
    id INT(11) NOT NULL AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL COMMENT 'News article title',
    content TEXT NOT NULL COMMENT 'Full news article content',
    excerpt VARCHAR(500) DEFAULT NULL COMMENT 'Short description/excerpt for listings',
    image VARCHAR(255) DEFAULT NULL COMMENT 'Path to news image (uploaded or URL)',
    author VARCHAR(100) DEFAULT 'Admin' COMMENT 'Author of the news article',
    status ENUM('published', 'draft') DEFAULT 'published' COMMENT 'Publication status',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Date and time when news was created',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date and time when news was last updated',
    PRIMARY KEY (id),
    KEY idx_status (status),
    KEY idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='News articles and blog posts';



