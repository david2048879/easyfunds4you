<?php
/**
 * Process Loan Application
 * Easy Funds 4 You
 */

// Start session for storing messages
session_start();

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: apply.php');
    exit;
}

// Include database configuration
require_once 'config/database.php';

// Get form data and sanitize
$loan_type = isset($_POST['loan_type']) ? htmlspecialchars(trim($_POST['loan_type'])) : '';
$loan_amount = isset($_POST['loan_amount']) ? floatval($_POST['loan_amount']) : 0;
$loan_duration = isset($_POST['loan_duration']) ? intval($_POST['loan_duration']) : 0;
$gender = isset($_POST['gender']) ? htmlspecialchars(trim($_POST['gender'])) : '';
$first_name = isset($_POST['first_name']) ? htmlspecialchars(trim($_POST['first_name'])) : '';
$last_name = isset($_POST['last_name']) ? htmlspecialchars(trim($_POST['last_name'])) : '';
$dependants = isset($_POST['dependants']) ? htmlspecialchars(trim($_POST['dependants'])) : '';
$email = isset($_POST['email']) ? filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL) : '';
$phone = isset($_POST['phone']) ? htmlspecialchars(trim($_POST['phone'])) : '';
$marital_status = isset($_POST['marital_status']) ? htmlspecialchars(trim($_POST['marital_status'])) : '';
$city = isset($_POST['city']) ? htmlspecialchars(trim($_POST['city'])) : '';
$street = isset($_POST['street']) ? htmlspecialchars(trim($_POST['street'])) : '';
$house_number = isset($_POST['house_number']) ? htmlspecialchars(trim($_POST['house_number'])) : '';
$homeowner_status = isset($_POST['homeowner_status']) ? htmlspecialchars(trim($_POST['homeowner_status'])) : '';
$employment_industry = isset($_POST['employment_industry']) ? htmlspecialchars(trim($_POST['employment_industry'])) : '';
$employer_name = isset($_POST['employer_name']) ? htmlspecialchars(trim($_POST['employer_name'])) : '';
$work_phone = isset($_POST['work_phone']) ? htmlspecialchars(trim($_POST['work_phone'])) : '';
$monthly_income = isset($_POST['monthly_income']) ? floatval($_POST['monthly_income']) : 0;
$notes = isset($_POST['notes']) ? htmlspecialchars(trim($_POST['notes'])) : '';

// Basic validation
$errors = [];

if (empty($loan_type)) $errors[] = 'Loan type is required';
if ($loan_amount <= 0) $errors[] = 'Valid loan amount is required';
if ($loan_duration <= 0) $errors[] = 'Valid loan duration is required';
if (empty($first_name)) $errors[] = 'First name is required';
if (empty($last_name)) $errors[] = 'Last name is required';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required';
if (empty($phone)) $errors[] = 'Phone number is required';

// If there are errors, redirect back to form
if (!empty($errors)) {
    $_SESSION['errors'] = $errors;
    $_SESSION['form_data'] = $_POST;
    header('Location: apply.php');
    exit;
}

// Connect to database
$conn = getDBConnection();

if ($conn) {
    // Create applications table if it doesn't exist
    $create_table = "CREATE TABLE IF NOT EXISTS loan_applications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        loan_type VARCHAR(50) NOT NULL,
        loan_amount DECIMAL(15,2) NOT NULL,
        loan_duration INT NOT NULL,
        gender VARCHAR(10),
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NOT NULL,
        dependants VARCHAR(10),
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        marital_status VARCHAR(20),
        city VARCHAR(100),
        street VARCHAR(255),
        house_number VARCHAR(100),
        homeowner_status VARCHAR(50),
        employment_industry VARCHAR(255),
        employer_name VARCHAR(255),
        work_phone VARCHAR(50),
        monthly_income DECIMAL(15,2),
        notes TEXT,
        status VARCHAR(20) DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $conn->query($create_table);
    
    // Insert application
    $stmt = $conn->prepare("INSERT INTO loan_applications 
        (loan_type, loan_amount, loan_duration, gender, first_name, last_name, dependants, 
         email, phone, marital_status, city, street, house_number, homeowner_status, 
         employment_industry, employer_name, work_phone, monthly_income, notes) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $stmt->bind_param("sdississsssssssssds", 
        $loan_type, $loan_amount, $loan_duration, $gender, $first_name, $last_name, 
        $dependants, $email, $phone, $marital_status, $city, $street, $house_number, 
        $homeowner_status, $employment_industry, $employer_name, $work_phone, 
        $monthly_income, $notes);
    
    if ($stmt->execute()) {
        $application_id = $conn->insert_id;
        $stmt->close();
        closeDBConnection($conn);
        
        // Success - redirect to thank you page
        $_SESSION['success'] = true;
        $_SESSION['application_id'] = $application_id;
        header('Location: application_success.php');
        exit;
    } else {
        $errors[] = 'Failed to submit application. Please try again.';
        $_SESSION['errors'] = $errors;
        $_SESSION['form_data'] = $_POST;
        $stmt->close();
        closeDBConnection($conn);
        header('Location: apply.php');
        exit;
    }
} else {
    // Database connection failed - could send email instead or save to file
    // For now, redirect with error
    $_SESSION['errors'] = ['Database connection failed. Please contact us directly at +250796693784 or info@easyfunds4you.rw'];
    $_SESSION['form_data'] = $_POST;
    header('Location: apply.php');
    exit;
}
?>



