// Contact form - No JavaScript validation needed
// Form submits directly to process_contact.php with HTML5 validation
// Server-side validation in process_contact.php handles all validation

// This file intentionally left minimal to avoid interfering with form submission
