<?php
/**
 * Admin Logout
 */
require_once 'config.php';
adminLogout();
?>








